package main;

import java.awt.Color;

public class GraphicsRect {

	public Color col;
	public Tuple pos;
	public Tuple size;
	
	public GraphicsRect(Color c, Tuple p, Tuple s) {
		col = c;
		pos = p;
		size = s;
	}
	
}