package main;

public enum AreaType {
	
	Forest,
	Swamp,
	Vulcano,
	Frozen,
	Desert,
	Sky
}