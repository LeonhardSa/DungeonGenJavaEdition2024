package main;

public class Tuple {
	public final int x;
	public final int y;
	public Tuple(int x, int y) { 
		this.x = x; 
	    this.y = y; 
	}
	public Tuple() { 
		this.x = 0; 
	    this.y = 0; 
	}
	
	public String toString() {
		return "[x=" + x + ", y=" + y + "]";
	}
}
