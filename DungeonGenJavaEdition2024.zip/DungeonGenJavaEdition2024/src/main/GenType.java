package main;

public enum GenType {

	Normal,
	OneRoomMH,
	TwoRoomMH,
	Crossroads,
	OuterRing,
	OuterRooms,
	Line,
	Bettle
	
}
