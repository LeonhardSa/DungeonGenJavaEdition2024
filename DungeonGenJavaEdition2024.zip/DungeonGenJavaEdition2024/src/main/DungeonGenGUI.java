package main;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.HashSet;
import java.util.Map;
import java.util.Queue; 
import java.util.Random;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.AffineTransform;
import java.awt.image.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.imageio.ImageIO;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.forms.layout.ColumnSpec;
import com.jgoodies.forms.layout.FormSpecs;
import com.jgoodies.forms.layout.RowSpec;

public class DungeonGenGUI extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	private ArrayList<GraphicsRect> gr = new ArrayList<GraphicsRect>();
	
	private JTabbedPane tabbedPane;
	private JPanel contGenSettings;
	private JPanel contImage;
	
	private BufferedImage bi;
	
	private Timer t = null;
	private Random rand;
	
	private JTextField txtRD;
	private JTextField txtMH;
	private JTextField txtMC;
	
	private JCheckBox chckbxVariance;
	private JComboBox<GenType> cmbBoxGenType;
	private JComboBox<AreaType> cmbBoxAreaType;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DungeonGenGUI frame = new DungeonGenGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public DungeonGenGUI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(50, 50, 444, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				java.util.Timer t = new java.util.Timer();
						t.schedule( new java.util.TimerTask() {
				            public void run() {
				            	DrawGraphicsRects(contImage);
				            	t.cancel();
				            }
				        }, 
				        5 
				);
				
			}
		});
		tabbedPane.setBounds(10, 25, 414, 230);
		contentPane.add(tabbedPane);
		
		contGenSettings = new JPanel();
		tabbedPane.addTab("Settings", null, contGenSettings, null);
		contGenSettings.setLayout(new FormLayout(new ColumnSpec[] {
				FormSpecs.UNRELATED_GAP_COLSPEC,
				ColumnSpec.decode("90px"),
				FormSpecs.RELATED_GAP_COLSPEC,
				FormSpecs.DEFAULT_COLSPEC,
				FormSpecs.UNRELATED_GAP_COLSPEC,
				ColumnSpec.decode("46px"),
				FormSpecs.RELATED_GAP_COLSPEC,
				FormSpecs.DEFAULT_COLSPEC,
				FormSpecs.LABEL_COMPONENT_GAP_COLSPEC,
				ColumnSpec.decode("80px"),
				FormSpecs.RELATED_GAP_COLSPEC,
				ColumnSpec.decode("default:grow"),},
			new RowSpec[] {
				FormSpecs.UNRELATED_GAP_ROWSPEC,
				RowSpec.decode("20px"),
				FormSpecs.UNRELATED_GAP_ROWSPEC,
				RowSpec.decode("20px"),
				FormSpecs.UNRELATED_GAP_ROWSPEC,
				RowSpec.decode("20px"),
				FormSpecs.RELATED_GAP_ROWSPEC,
				FormSpecs.DEFAULT_ROWSPEC,
				FormSpecs.RELATED_GAP_ROWSPEC,
				FormSpecs.DEFAULT_ROWSPEC,}));
		
		cmbBoxGenType = new JComboBox();
		cmbBoxGenType.setModel(new DefaultComboBoxModel(GenType.values()));
		contGenSettings.add(cmbBoxGenType, "2, 2, 3, 1, fill, default");
		
		chckbxFlooded = new JCheckBox("Flooded");
		contGenSettings.add(chckbxFlooded, "10, 2");
		
		cmbBoxAreaType = new JComboBox();
		cmbBoxAreaType.setModel(new DefaultComboBoxModel(AreaType.values()));
		contGenSettings.add(cmbBoxAreaType, "2, 4, 3, 1, fill, default");
		
		JLabel lblNewLabel = new JLabel("Nbr. of Rooms:");
		contGenSettings.add(lblNewLabel, "2, 6, left, center");
		
		txtRD = new JTextField();
		txtRD.setHorizontalAlignment(SwingConstants.TRAILING);
		txtRD.setText("6");
		txtRD.setColumns(10);
		contGenSettings.add(txtRD, "6, 6, fill, top");
		
		chckbxVariance = new JCheckBox("Variance");
		contGenSettings.add(chckbxVariance, "10, 6, 2, 1");
		
		JLabel lblNewLabel_1 = new JLabel("Mon. H. Chance:");
		contGenSettings.add(lblNewLabel_1, "2, 8, left, center");
		
		txtMH = new JTextField();
		txtMH.setHorizontalAlignment(SwingConstants.TRAILING);
		txtMH.setText("100");
		txtMH.setColumns(10);
		contGenSettings.add(txtMH, "6, 8, fill, top");
		
		JLabel lblNewLabel_2 = new JLabel("%");
		contGenSettings.add(lblNewLabel_2, "8, 8, left, center");
		
		chckbxMHStairs = new JCheckBox("MH Stairs");
		contGenSettings.add(chckbxMHStairs, "10, 8, 2, 1");
		
		JLabel lblNewLabel_3 = new JLabel("Merchant Chance:");
		contGenSettings.add(lblNewLabel_3, "2, 10, left, center");
		
		txtMC = new JTextField();
		txtMC.setHorizontalAlignment(SwingConstants.TRAILING);
		txtMC.setText("100");
		txtMC.setColumns(10);
		contGenSettings.add(txtMC, "6, 10, fill, top");
		
		JLabel lblNewLabel_2_1 = new JLabel("%");
		contGenSettings.add(lblNewLabel_2_1, "8, 10, left, top");
		
		contImage = new JPanel();
		tabbedPane.addTab("Image", null, contImage, null);
		contImage.setLayout(null);
		
		addComponentListener(new ComponentAdapter() {
			@Override
			public void componentResized(ComponentEvent e) {
				FitToWindow();
			}
		});
		
		JButton btnGenMe = new JButton("Gen Me!");
		btnGenMe.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tabbedPane.setSelectedIndex(1);
				try {
					rand = new Random();
					CreateDungeon();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnGenMe.setBounds(10, 0, 89, 23);
		contentPane.add(btnGenMe);
		
		JButton btnExport = new JButton("Export!");
		btnExport.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tabbedPane.setSelectedIndex(1);
				if(bi != null) {
					FitToContent();
					java.util.Timer t = new java.util.Timer();
					t.schedule( new java.util.TimerTask() {
			            public void run() {
			            	try {
			            		ImageIO.write(bi, "PNG", new File("MysterdyDungeon_"+LocalDateTime.now().format(DateTimeFormatter.ofPattern("MM-dd_HH-mm-ss"))+".png"));
			            	} catch (IOException e1) {
			            		// TODO Auto-generated catch block
			            		e1.printStackTrace();
			            	}
			            	t.schedule( new java.util.TimerTask() {
								public void run() {
									FitToWindow();
					            	t.cancel();
								}
			            	}, 25 );
			            }
			        }, 25 );
				} 
			}
		});
		btnExport.setBounds(110, 0, 89, 23);
		contentPane.add(btnExport);
	}
	
	void AddNewGRect(GraphicsRect grect) {
		if(gr.contains(grect)) return;
		gr.add(grect);
	}
	
	void DrawGraphicsRects(JPanel panel) {
		if(tabbedPane.getSelectedIndex()!=1) return;
		
		bi = new BufferedImage(contImage.getSize().width, contImage.getSize().height, BufferedImage.TYPE_3BYTE_BGR);
		
		Graphics g = bi.createGraphics();
		
		g.setColor(new Color(240, 240, 240));
		g.fillRect(0, 0, bi.getWidth(), bi.getHeight());
		
		for(GraphicsRect grs : gr){
			g.setColor(grs.col);
			g.fillRect(grs.pos.x, grs.pos.y, grs.size.x, grs.size.y);
		}
		
		Graphics cIg = contImage.getGraphics().create();
		cIg.drawImage(bi, 0, 0, null);
		contImage.paintComponents(cIg);
	}
	
	// ACTUAL DUNGEON GEN!!!!
	
	//Variables for DungeonGen
	private int roomNum;
	private boolean mhChance;
	private boolean mcChance;
	private boolean flooded;
	private boolean variance;
	private boolean mhStairs;
	private GenType genType;
	private AreaType areaType;
	
	private Color[][] dungeon;
	private Tuple[][] paths;
	private Tuple[][] anchors;
	
	private final int tileSize = 12;
	
	private static Map<String, Color> tileColors;
	private static Map<String, Color> tileColorsForest;
	private static Map<String, Color> tileColorsSwamp;
	private static Map<String, Color> tileColorsVulcano;
	private static Map<String, Color> tileColorsFrozen;
	private static Map<String, Color> tileColorsDesert;
	private static Map<String, Color> tileColorsSky;
	private JCheckBox chckbxMHStairs;
	private JCheckBox chckbxFlooded;
	
	static {
		tileColors = new HashMap();
		tileColors.put("Empty", new Color(0x808080));
		tileColors.put("Room", new Color(0x95DB48));
		tileColors.put("Path", new Color(0xD97D48));
		tileColors.put("AreaWall", new Color(0xA9A9A9));
		tileColors.put("MonsterHouse", new Color(0xFA160A));
		tileColors.put("Merchant", new Color(0xFFA6E1));
		tileColors.put("Water", new Color(0x508BFA));
		tileColors.put("Spawn", new Color(0xFFA000));
		tileColors.put("Stairs", new Color(0xE24FFA));
	}
	
	static {
		tileColorsForest = new HashMap();
		tileColorsForest.put("Room", new Color(0x95DB48));
		tileColorsForest.put("Path", new Color(0xD97D48));
		tileColorsForest.put("Water", new Color(0x508BFA));
	}
	
	static {
		tileColorsSwamp = new HashMap();
		tileColorsSwamp.put("Room", new Color(0x2D936C));
		tileColorsSwamp.put("Path", new Color(0x899878));
		tileColorsSwamp.put("Water", new Color(0x48483A));
	}
	
	static {
		tileColorsVulcano = new HashMap();
		tileColorsVulcano.put("Room", new Color(0xBC412B));
		tileColorsVulcano.put("Path", new Color(0x5E503F));
		tileColorsVulcano.put("Water", new Color(0x870202));
	}
	
	static {
		tileColorsFrozen = new HashMap();
		tileColorsFrozen.put("Room", new Color(0xEFEFEF));
		tileColorsFrozen.put("Path", new Color(0x86BBD8));
		tileColorsFrozen.put("Water", new Color(0xAEB8FE));
	}
	
	static {
		tileColorsDesert = new HashMap();
		tileColorsDesert.put("Room", new Color(0xE5B181));
		tileColorsDesert.put("Path", new Color(0xDE8F6E));
		tileColorsDesert.put("Water", new Color(0xD34E24));
	}
	
	static {
		tileColorsSky = new HashMap();
		tileColorsSky.put("Room", new Color(0xFFE66D));
		tileColorsSky.put("Path", new Color(0xCDDFA0));
		tileColorsSky.put("Water", new Color(0xF1F2F6));
	}
	

	
	private void FitToContent() {
		tabbedPane.setSize(dungeon.length*tileSize+5, dungeon[0].length*tileSize+25);
	}
	
	private void TryResizeToFitContent() {
		
		int w = getBounds().width;
		if(getBounds().width < dungeon.length*tileSize+40) w = dungeon.length*tileSize+40;
		int h = getBounds().height;
		if(getBounds().height < dungeon[0].length*tileSize+100) h = dungeon[0].length*tileSize+100;
		
		setBounds(getBounds().x, getBounds().y, w, h);
		
		FitToWindow();
	}
	
	private void FitToWindow() {
		tabbedPane.setSize(contentPane.getWidth() - 20, contentPane.getHeight() - 35);
	}
	
	private void CreateDungeon() throws IOException {
		System.out.println("Read Settings...");
		ReadDungeonSetting();
		System.out.println("Setup Room Balancing...");
		RandomizeForRoomSetup();
		System.out.println("Resize Window to fit...");
		TryResizeToFitContent();
		System.out.print("Generate Rooms and Anchors...");
		System.out.println(" add Special Areas if Existent");
		GenerateRoomsAndAnchors();
		System.out.println("Generate Path Directions and Paths...");
		GeneratePaths();
		System.out.println("I cast \"Create Water\"...");
		GenerateEnvironmenifer();
		System.out.println("Generate Entry and Exit Positions...");
		EntryAndExit();
		System.out.println("Setup Rects to Draw...");
		SetupGraphicRects();
		System.out.println("Draw Dungeon...");
		SetupTimerForRedraw();
		DrawGraphicsRects(contImage);
	}
	
	private void SetupTimerForRedraw() {
		if(t == null) {
			t = new Timer(0, null);

			t.addActionListener(new ActionListener() {

			    @Override
			    public void actionPerformed(ActionEvent e) {
			    	DrawGraphicsRects(contImage);
			    }
			});

			t.setRepeats(true);
			t.setDelay(10);
			t.start(); 
		}
	}

	private void ReadDungeonSetting() {
		
		flooded = chckbxFlooded.isSelected();
		
		variance = chckbxVariance.isSelected();
		
		mhStairs = chckbxMHStairs.isSelected();
		
		//Read selected Generation Type
		genType = (GenType) cmbBoxGenType.getSelectedItem();
		
		//Read selected Color Palette
		areaType = (AreaType) cmbBoxAreaType.getSelectedItem();
		
		//Apply selected Color Palette
		switch (areaType) {
		case Forest:
			tileColors = tileColorsForest;
			break;
		case Swamp:
			tileColors = tileColorsSwamp;
			break;
		case Vulcano:
			tileColors = tileColorsVulcano;
			break;
		case Frozen:
			tileColors = tileColorsFrozen;
			break;
		case Desert:
			tileColors = tileColorsDesert;
			break;
		case Sky:
			tileColors = tileColorsSky;
			break;
		default:
			break;
		}
		
		
		//Add Rest of the Colors
		tileColors.put("Empty", new Color(0x808080));
		tileColors.put("AreaWall", new Color(0xA9A9A9));
		tileColors.put("MonsterHouse", new Color(0xFA160A));
		tileColors.put("Merchant", new Color(0xFFA6E1));
		tileColors.put("Spawn", new Color(0xFFAF1C));
		tileColors.put("Stairs", new Color(0xE24FFA)); 
		
		try {
			roomNum = Integer.parseInt(txtRD.getText());
			if(variance) roomNum += (rand.nextInt(5)-2);
		} catch (NumberFormatException nfe) {
			roomNum = 6;
		}
		
		switch (genType) {
		case Normal:
			roomNum = Math.min(25, roomNum);
			break;
		case OneRoomMH:
			roomNum = 1;
			break;
		case TwoRoomMH:
			roomNum = 2;
			break;
		case Crossroads:
			roomNum = Math.min(20, Math.max(4, roomNum));
			break;
		case OuterRing:
			roomNum = Math.min(21, roomNum);
			break;
		case OuterRooms:
			roomNum = Math.min(24, Math.max(8, roomNum));
			break;
		case Line:
			roomNum = Math.min(8, Math.max(2, roomNum));
			break;
		case Bettle:
			roomNum = Math.min(11, Math.max(5, roomNum));
			break;
		default:
			break;
		}
		
		try {
			mhChance = rand.nextInt(100) < Integer.parseInt(txtMH.getText());
		} catch (NumberFormatException nfe) {
			mhChance = false;
		}
		
		if(genType == GenType.TwoRoomMH) mhChance = true;
		
		try {
			mcChance = rand.nextInt(100) < Integer.parseInt(txtMC.getText());
		} catch (NumberFormatException nfe) {
			mcChance = false;
		}
	}
	
	private void RandomizeForRoomSetup() throws IOException {
		
		String readFile = "ScientificDatabankForRooms.xlsx";
		
		//Change File if needed
		if(genType == GenType.Crossroads || genType == GenType.OuterRooms) {
			readFile = "ScientificDatabankForCrossRoads.xlsx";
		}
		else if(genType == GenType.OuterRing) {
			readFile = "ScientificDatabankForOuterRing.xlsx";
		}
		else if(genType == GenType.Bettle) {
			readFile = "ScientificDatabankForBettles.xlsx";
		}
		
		//Project Version
		FileInputStream fis = new FileInputStream(System.getProperty("user.dir")+"/src/main/"+readFile);
		//Jar Version
		//FileInputStream fis = new FileInputStream(System.getProperty("user.dir")+"/DungeonGenV1.1_lib/"+readFile);
		
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sheet = wb.getSheetAt(0);
		
		int rowVal = 0;
		int col = -1;
		
		if(genType == GenType.OuterRooms) roomNum -= 4;
		
		do {
			
			col = rand.nextInt(8)+1;
			rowVal = (int) sheet.getRow(roomNum-1).getCell(col).getNumericCellValue();
		} while (rowVal == 0);
		col+=1;
		
		if(genType == GenType.OuterRooms) roomNum += 4;
		
		if(genType != GenType.OuterRing && roomNum == 1) {
			col = 1;
			rowVal = 1;
		}
		
		if(genType == GenType.OneRoomMH || genType == GenType.TwoRoomMH) {
			col = 2;
			rowVal = 2;
		}
		
		else if(genType == GenType.Line) {
			rowVal = 1;
			col = roomNum;
		}
		
		if(genType == GenType.OuterRing) {
			roomNum = col*rowVal - ((col-1)+(rowVal-1))*2;
		}
		
		else if(genType == GenType.Crossroads) {
			roomNum = ((col-2)+(rowVal-2))*2;
		}
		
		else if(genType == GenType.OuterRooms) {
			roomNum = ((col-1)+(rowVal-1))*2;
		}
		
		else if(genType == GenType.Bettle) {
			if(roomNum % 2 == 0) roomNum++;
		}
		
		dungeon = new Color[col*11+1][rowVal*11+1];
		paths = new Tuple[col][rowVal];
		anchors = new Tuple[col][rowVal];
		
		for(int x = 0; x < dungeon.length; x++) {
			for(int y = 0; y < dungeon[0].length; y++) {
				if(x%11==0||y%11==0) dungeon[x][y] = tileColors.get("AreaWall");
				else dungeon[x][y] = tileColors.get("Empty");
			}
		}
	}

	private void GenerateRoomsAndAnchors() {
		HashSet<Tuple> rooms = new HashSet<Tuple>();
		
		Tuple mhRoom = new Tuple(-1, -1);
		Tuple mcRoom = new Tuple(-1, -1);
		int mhRoomNum = -1;
		int mcRoomNum = -1;
		
		if(mhChance) {
			mhRoomNum = rand.nextInt(roomNum);
		}
		else {
			mhStairs = false;
		}
		if(mcChance && !mhChance || mcChance && roomNum > 1) {
			mcRoomNum = mhRoomNum;
			while(mcRoomNum == mhRoomNum) {
				mcRoomNum = rand.nextInt(roomNum);
			}
		}
		
		int roomCount = 0;
		do {
			if(genType == GenType.Normal || genType == GenType.Line) {
				int c = rand.nextInt(anchors.length);
				int r = rand.nextInt(anchors[0].length);
				Tuple t = new Tuple(c, r);
				if(!HashSetCompareTuple(rooms, t)) {
					rooms.add(t);
					roomCount++;
					
					if(roomCount == mhRoomNum+1) mhRoom = t;
					if(roomCount == mcRoomNum+1) mcRoom = t;
				}
			}
			else if(genType == GenType.Crossroads) {
				int c = -1;
				int r = -1;
				
				if(roomCount < (anchors.length-2)*2) {
					c = rand.nextInt(anchors.length-2)+1;
					r = rand.nextInt(2) * (anchors[0].length-1);
				}
				else {
					c = rand.nextInt(2) * (anchors.length-1);
					r = rand.nextInt(anchors[0].length-2)+1;
				}
				
				Tuple t = new Tuple(c, r);
				
				if(!HashSetCompareTuple(rooms, t)) {
					rooms.add(t);
					roomCount++;
					
					if(roomCount == mhRoomNum+1) mhRoom = t;
					if(roomCount == mcRoomNum+1) mcRoom = t;
				}
			}
			else if(genType == GenType.OuterRing) {
				int c = rand.nextInt(anchors.length-2)+1;
				int r = rand.nextInt(anchors[0].length-2)+1;
				Tuple t = new Tuple(c, r);
				if(!HashSetCompareTuple(rooms, t)) {
					rooms.add(t);
					roomCount++;
					
					if(roomCount == mhRoomNum+1) mhRoom = t;
					if(roomCount == mcRoomNum+1) mcRoom = t;
				}
			}
			else if(genType == GenType.OuterRooms) {
				int c = -1;
				int r = -1;
				
				if(roomCount < anchors.length*2) {
					c = rand.nextInt(anchors.length);
					r = rand.nextInt(2) * (anchors[0].length-1);
				}
				else {
					c = rand.nextInt(2) * (anchors.length-1);
					r = rand.nextInt(anchors[0].length-2)+1;
				}
				
				Tuple t = new Tuple(c, r);
				
				if(!HashSetCompareTuple(rooms, t)) {
					rooms.add(t);
					roomCount++;
					
					if(roomCount == mhRoomNum+1) mhRoom = t;
					if(roomCount == mcRoomNum+1) mcRoom = t;
				}
			}
			else if(genType == GenType.Bettle) {
				if(roomCount == 0) {
					rooms.add(new Tuple(1, 0));
					roomCount++;
					
					if(roomCount == mhRoomNum+1) mhRoom = new Tuple(1, 0);
					if(roomCount == mcRoomNum+1) mcRoom = new Tuple(1, 0);
				}
				else {
					int c = rand.nextInt(2) * (anchors.length-1);
					int r = rand.nextInt(anchors[0].length);
					
					Tuple t = new Tuple(c, r);
					
					if(!HashSetCompareTuple(rooms, t)) {
						rooms.add(t);
						roomCount++;
						
						if(roomCount == mhRoomNum+1) mhRoom = t;
						if(roomCount == mcRoomNum+1) mcRoom = t;
					}
				}
			}
			else if(genType == GenType.OneRoomMH) {
				rooms.add(new Tuple(0, 0));
				mhRoom = new Tuple(0, 0);
				roomCount++;
			}
			else if(genType == GenType.TwoRoomMH) {
				rooms.add(new Tuple(0, 0));
				roomCount++;
				if(roomCount == mhRoomNum+1) mhRoom = new Tuple(0, 0);
				if(roomCount == mcRoomNum+1) mcRoom = new Tuple(0, 0);
				rooms.add(new Tuple(1, 0));
				roomCount++;
				if(roomCount == mhRoomNum+1) mhRoom = new Tuple(1, 0);
				if(roomCount == mcRoomNum+1) mcRoom = new Tuple(1, 0);
			}
			
		} while (roomCount < roomNum);
		
		for(int x = 0; x < anchors.length; x++) {
			for(int y = 0; y < anchors[0].length; y++) {
				
				//Going through all areas to find which ones are supposed to have a room
				if(HashSetCompareTuple(rooms, new Tuple(x, y))) {
					
					Tuple corner1 = new Tuple();
					Tuple corner2 = new Tuple();
					
					if(genType != GenType.OneRoomMH && genType != GenType.TwoRoomMH && genType != GenType.Bettle) {
					//Randomizing Rooom Bounds
						corner1 = new Tuple(rand.nextInt(7), rand.nextInt(7));
						corner2 = new Tuple(rand.nextInt(7-corner1.x)+corner1.x+4,
											rand.nextInt(7-corner1.y)+corner1.y+4);
					}
					else if(genType == GenType.OneRoomMH) {
						corner1 = new Tuple(rand.nextInt(5), rand.nextInt(5));
						corner2 = new Tuple(rand.nextInt(5-corner1.x)+corner1.x+15,
											rand.nextInt(5-corner1.y)+corner1.y+15);
					}
					else if(genType == GenType.TwoRoomMH) {
						corner1 = new Tuple(rand.nextInt(3), rand.nextInt(3));
						corner2 = new Tuple(rand.nextInt(3-corner1.x)+corner1.x+7,
											rand.nextInt(3-corner1.y)+corner1.y+17);
					}
					else if(genType == GenType.Bettle) {
						//Bettle Room
						if(x == 1 && y == 0) {
							corner1 = new Tuple(rand.nextInt(5), rand.nextInt(5));
							corner2 = new Tuple(rand.nextInt(5-corner1.x)+corner1.x+5+(anchors.length-3)*10,
												rand.nextInt(5-corner1.y)+corner1.y+5+(anchors[0].length-1)*10);
						}
						//Other Rooms
						else {
							corner1 = new Tuple(rand.nextInt(7), rand.nextInt(7));
							corner2 = new Tuple(rand.nextInt(7-corner1.x)+corner1.x+4,
												rand.nextInt(7-corner1.y)+corner1.y+4);
						}
					}
					
					//Iterating through Room Bounds
					for(int dx = x*11+corner1.x+1; dx < x*11+corner2.x+1; dx++) {
						for(int dy = y*11+corner1.y+1; dy < y*11+corner2.y+1; dy++) {
							
							//Place Normal Room
							dungeon[dx][dy] = tileColors.get("Room");
							
							//Replace in case of Monster House
							if(mhRoom.x == x && mhRoom.y == y) dungeon[dx][dy] = tileColors.get("MonsterHouse");
						}
					}
					
					//Normal Room Anchor
					anchors[x][y] = new Tuple(x*11+(corner2.x-corner1.x)/2+corner1.x+1, y*11+(corner2.y-corner1.y)/2+corner1.y+1);
					
					//Place Merchant of existent
					if(mcRoom.x == x && mcRoom.y == y) {
						int dx = anchors[x][y].x;
						int dy = anchors[x][y].y;
						dungeon[dx][dy] = tileColors.get("Merchant");
						dungeon[dx+1][dy] = tileColors.get("Merchant");
						dungeon[dx-1][dy] = tileColors.get("Merchant");
						dungeon[dx][dy+1] = tileColors.get("Merchant");
						dungeon[dx][dy-1] = tileColors.get("Merchant");
						dungeon[dx+1][dy+1] = tileColors.get("Merchant");
						dungeon[dx+1][dy-1] = tileColors.get("Merchant");
						dungeon[dx-1][dy+1] = tileColors.get("Merchant");
						dungeon[dx-1][dy-1] = tileColors.get("Merchant");
					}
					
					//Bettle Room Anchor
					if(genType == GenType.Bettle && x == 1 && y == 0) {
						anchors[x][y] = new Tuple(x*11+rand.nextInt(10)+1, y*11+rand.nextInt(10)+1);
					}
				}
				else {
					anchors[x][y] = new Tuple(x*11+rand.nextInt(10)+1, y*11+rand.nextInt(10)+1);
				}
			}
		}
	}
	
	private void GeneratePaths() {
		
		//
		// Generate Path Directions!!!
		//
		final Tuple[] tDir = new Tuple[]{new Tuple(0, -1), new Tuple(1, 0), new Tuple(0, 1), new Tuple(-1, 0)};
		HashSet<Integer> usedDir = new HashSet<Integer>(); 
		
		ArrayList<Tuple> path = new ArrayList<Tuple>();
		path.add(new Tuple((int)paths.length/2, (int)paths[0].length/2));
		Tuple newPos = path.get(path.size()-1);
		Tuple randT;
		int r = -1;
		
		while(path.size() > 0) {
			
			//Get Next Random Direction
			do {
				usedDir.add(r);
				r = rand.nextInt(4);
				randT = null;
				randT = tDir[r];
			} while (usedDir.contains(r) && usedDir.size() < 5);
			
			if(usedDir.size() == 5) {
				
				if(paths[newPos.x][newPos.y] == null) {
					paths[newPos.x][newPos.y] = new Tuple(0, 0);
				}
				
				//Update current Pos
				path.remove(path.size()-1);
				if(path.size()>0) newPos = path.get(path.size()-1);
				
				//Reset Random Direction Setup
				r=-1;
				usedDir.clear();
				
				continue;
			}
			
			if((newPos.x + randT.x >= 0 && newPos.x + randT.x < paths.length &&
				newPos.y + randT.y >= 0 && newPos.y + randT.y < paths[0].length)) {
				
				Tuple posNewPos = new Tuple(newPos.x + randT.x, newPos.y + randT.y);
				if(paths[posNewPos.x][posNewPos.y] == null) {
					
					//Update Path Info
					if(randT.x == 1 || randT.y == 1) {
						if(paths[newPos.x][newPos.y] == null) {
							paths[newPos.x][newPos.y] = randT;
						}
						else {
							paths[newPos.x][newPos.y] = new Tuple(1, 1);
						}
						
					}
					else {
						paths[posNewPos.x][posNewPos.y] = new Tuple(randT.x * -1, randT.y * -1);
						if(paths[newPos.x][newPos.y] == null) {
							paths[newPos.x][newPos.y] = new Tuple(0, 0);
						}
					}
					
					//Update current Pos
					path.add(new Tuple(posNewPos.x, posNewPos.y));
					newPos = posNewPos;
					
					//Reset Random Direction Setup
					r=-1;
					usedDir.clear();
				}
			}
		}
		
		//Add a few random crossings
		for(int c = 0; c < paths.length && c < paths[0].length; c++) {
			Tuple randomArea = new Tuple(rand.nextInt(paths.length), rand.nextInt(paths[0].length));
			paths[randomArea.x][randomArea.y] = new Tuple(1, 1);
		}
		
		//If Generation Type is Outer Ring connect all outside paths
		if(genType == GenType.OuterRing) {
			for(int x = 0; x < paths.length-1; x++) {
				paths[x][0] = new Tuple(1, paths[x][0].y);
				paths[x][paths[0].length-1] = new Tuple(1, paths[x][paths[0].length-1].y);
			}
			for(int y = 0; y < paths[0].length-1; y++) {
				paths[0][y] = new Tuple(paths[0][y].x, 1);
				paths[paths.length-1][y] = new Tuple(paths[paths.length-1][y].x, 1);
			}
		}
		
		//If Generation Type is Crossroads connect all inside paths
		if(genType == GenType.Crossroads) {
			for(int x = 1; x < paths.length-1; x++) {
				for(int y = 1; y < paths[0].length-1; y++) {
					paths[x][y] = new Tuple(1, 1);
				}
			}
			for(int x = 1; x < paths.length-1; x++) {
				paths[x][0] = new Tuple(paths[x][0].x, 1);
			}
			
			for(int y = 1; y < paths[0].length-1; y++) {
				paths[0][y] = new Tuple(1, paths[0][y].y);
			}
			
			//Remove all connection from and to corner areas
			paths[0][0] = new Tuple(0, 0);
			paths[paths.length-1][0] = new Tuple(paths[paths.length-1][0].x, 0);
			paths[paths.length-2][0] = new Tuple(0, paths[paths.length-2][0].y);
			paths[0][paths[0].length-1] = new Tuple(0, paths[0][paths[0].length-1].y);
			paths[0][paths[0].length-2] = new Tuple(paths[0][paths[0].length-2].x, 0);
			paths[paths.length-2][paths[0].length-1] = new Tuple(0, paths[paths.length-2][paths[0].length-1].y);
			paths[paths.length-1][paths[0].length-2] = new Tuple(paths[paths.length-1][paths[0].length-2].x, 0);
			
		}
		
		//If Generation Type is Outer Rooms remove all connections and connect everything on the outside
		if(genType == GenType.OuterRooms) {
			for(int x = 0; x < paths.length; x++) {
				for(int y = 0; y < paths[0].length; y++) {
					paths[x][y] = new Tuple();
				}
			}
			for(int x = 0; x < paths.length; x++) {
				paths[x][0] = new Tuple(1, paths[x][0].y);
				paths[x][paths[0].length-1] = new Tuple(1, paths[x][paths[0].length-1].y);
			}
			for(int y = 0; y < paths[0].length; y++) {
				paths[0][y] = new Tuple(paths[0][y].x, 1);
				paths[paths.length-1][y] = new Tuple(paths[paths.length-1][y].x, 1);
			}
		}
		
		//If Generation Type is OneRoomMH or TwoRoomMH remove all paths in the area
		if(genType == GenType.OneRoomMH || genType == GenType.TwoRoomMH) {
			for(int x = 0; x < paths.length; x++) {
				for(int y = 0; y < paths[0].length; y++) {
					paths[x][y] = new Tuple();
				}
			}
			//If it is TwoRoomMH reconnect the 2 rooms
			if(genType == GenType.TwoRoomMH) paths[0][0] = new Tuple(1, 0);
		}		
		
		//If Generation Type is Bettle connect all paths below the middle room, to secure a connection and connect the outside rooms in
		if(genType == GenType.Bettle) {
			for(int x = 0; x < paths.length; x++) {
				for(int y = 0; y < paths[0].length; y++) {
					if(x == 0 || x == paths.length-2) {
						paths[x][y] = new Tuple(1, paths[x][y].y);
					}
					if(x < paths.length-1 && x != 0){
						paths[x][y] = new Tuple(1, 1);
					}
				}
			}
		}
		
		//Remove Paths into the void
		for(int x = 0; x < paths.length; x++) {
			paths[x][paths[0].length-1] = new Tuple(paths[x][paths[0].length-1].x, 0);
		}
		for(int y = 0; y < paths[0].length; y++) {
			paths[paths.length-1][y] = new Tuple(0, paths[paths.length-1][y].y);
		}
		
		//
		// Generate Paths!!!
		//
		double randX;
		double randY;
		
		for(int x = 0; x < anchors.length; x++) {
			for(int y = 0; y < anchors[0].length; y++) {
				
				if(paths[x][y].x == 1) {
					
					randX = (double)((anchors[x+1][y].x - anchors[x][y].x + 1)/2);
					int xDis = rand.nextInt((int)randX) + rand.nextInt((int)Math.ceil(randX));
					
					for(int dx = anchors[x][y].x; dx < anchors[x][y].x + xDis; dx++) {
						if(dungeon[dx][anchors[x][y].y] == tileColors.get("Empty") ||
						dungeon[dx][anchors[x][y].y] == tileColors.get("AreaWall"))dungeon[dx][anchors[x][y].y] = tileColors.get("Path");
					}
					
					if(anchors[x][y].y < anchors[x+1][y].y)
					{
						for(int dy = anchors[x][y].y; dy < anchors[x+1][y].y; dy++) {
							if(dungeon[anchors[x][y].x + xDis][dy] == tileColors.get("Empty") ||
							dungeon[anchors[x][y].x + xDis][dy] == tileColors.get("AreaWall")) dungeon[anchors[x][y].x + xDis][dy] = tileColors.get("Path");
						}
					}
					else {
						for(int dy = anchors[x][y].y; dy > anchors[x+1][y].y; dy--) {
							if(dungeon[anchors[x][y].x + xDis][dy] == tileColors.get("Empty") ||
							dungeon[anchors[x][y].x + xDis][dy] == tileColors.get("AreaWall")) dungeon[anchors[x][y].x + xDis][dy] = tileColors.get("Path");
						}
					}
					
					for(int dx = anchors[x][y].x + xDis; dx < anchors[x+1][y].x+1; dx++) {
						if(dungeon[dx][anchors[x+1][y].y] == tileColors.get("Empty") ||
						dungeon[dx][anchors[x+1][y].y] == tileColors.get("AreaWall")) dungeon[dx][anchors[x+1][y].y] = tileColors.get("Path");
					}
				}
				if(paths[x][y].y == 1) {
					
					randY = (double)((anchors[x][y+1].y - anchors[x][y].y + 1)/2);
					int yDis = rand.nextInt((int)randY) + rand.nextInt((int)Math.ceil(randY));
					
					for(int dy = anchors[x][y].y; dy < anchors[x][y].y + yDis; dy++) {
						if(dungeon[anchors[x][y].x][dy] == tileColors.get("Empty") ||
						dungeon[anchors[x][y].x][dy] == tileColors.get("AreaWall")) dungeon[anchors[x][y].x][dy] = tileColors.get("Path");
					}
					
					if(anchors[x][y].x < anchors[x][y+1].x)
					{
						for(int dx = anchors[x][y].x; dx < anchors[x][y+1].x; dx++) {
							if(dungeon[dx][anchors[x][y].y + yDis] == tileColors.get("Empty") ||
							dungeon[dx][anchors[x][y].y + yDis] == tileColors.get("AreaWall")) dungeon[dx][anchors[x][y].y + yDis] = tileColors.get("Path");
						}
					}
					else {
						for(int dx = anchors[x][y].x; dx > anchors[x][y+1].x; dx--) {
							if(dungeon[dx][anchors[x][y].y + yDis] == tileColors.get("Empty") ||
							dungeon[dx][anchors[x][y].y + yDis] == tileColors.get("AreaWall")) dungeon[dx][anchors[x][y].y + yDis] = tileColors.get("Path");
						}
					}
					
					for(int dy = anchors[x][y].y + yDis; dy < anchors[x][y+1].y+1; dy++) {
						if(dungeon[anchors[x][y+1].x][dy] == tileColors.get("Empty") ||
						dungeon[anchors[x][y+1].x][dy] == tileColors.get("AreaWall")) dungeon[anchors[x][y+1].x][dy] = tileColors.get("Path");
					}
				}
			}
		}
	}
	
	private void GenerateEnvironmenifer() {
		
		for(int i = 0; i < (anchors.length*anchors[0].length)/2; i++) {
			
			//Roll for Position
			Tuple lakeside = new Tuple(rand.nextInt(paths.length), rand.nextInt(paths[0].length));
			//Set to middle if rolled the bottom right corner
			if(lakeside.x == paths.length-1 && lakeside.y == paths[0].length-1) {
				lakeside = new Tuple(lakeside.x/2, lakeside.y/2);
			}
			
			//Roll for directional offset to the main area
			boolean offset = rand.nextBoolean();
			if(lakeside.x == paths.length-1) offset = true;
			if(lakeside.y == paths[0].length-1) offset = false;
			
			HashSet<Tuple> usedTiles = new HashSet<Tuple>();
			Queue<Tuple> enviTiles = new LinkedList<Tuple>();
			int chance = 100;
			int queueCounter = 0;
			
			//Queue Starting Position
			if(offset) enviTiles.add(new Tuple(lakeside.x*10+5, lakeside.y*10+10));
			else enviTiles.add(new Tuple(lakeside.x*10+10, lakeside.y*10+5));
			usedTiles.add(enviTiles.peek());
			queueCounter = enviTiles.size();
			
			while(enviTiles.size() > 0) {
				Tuple enviTile = enviTiles.poll();
				queueCounter--;
				
				//Update Dungeon Tile with Water if reasonable
				if(dungeon[enviTile.x][enviTile.y] == tileColors.get("Empty") ||
				dungeon[enviTile.x][enviTile.y] == tileColors.get("AreaWall")) dungeon[enviTile.x][enviTile.y] = tileColors.get("Water");
				
				//If Generation Type Is Set to Flooded Simply place the EnvironmentTile
				if(flooded && dungeon[enviTile.x][enviTile.y] != tileColors.get("Merchant")) dungeon[enviTile.x][enviTile.y] = tileColors.get("Water");
				
				//Add new EnvironmentTiles into the Queue depending on the Odds/Chance
				if(enviTile.x - 1 >= 0) {
					Tuple t = new Tuple(enviTile.x - 1, enviTile.y);
					if(rand.nextInt(100) < chance && !HashSetCompareTuple(usedTiles, t)) {
						enviTiles.add(t);
					}
					usedTiles.add(t);
				}
				if(enviTile.x + 1 < dungeon.length-1) {
					Tuple t = new Tuple(enviTile.x + 1, enviTile.y);
					if(rand.nextInt(100) < chance && !HashSetCompareTuple(usedTiles, t)) {
						enviTiles.add(t);
					}
					usedTiles.add(t);
				}
				if(enviTile.y - 1 >= 0) {
					Tuple t = new Tuple(enviTile.x, enviTile.y - 1);
					if(rand.nextInt(100) < chance && !HashSetCompareTuple(usedTiles, t)) {
						enviTiles.add(t);
					}
					usedTiles.add(t);
				}
				if(enviTile.y + 1 < dungeon[0].length-1) {
					Tuple t = new Tuple(enviTile.x, enviTile.y + 1);
					if(rand.nextInt(100) < chance && !HashSetCompareTuple(usedTiles, t)) {
						enviTiles.add(t);
					}
					usedTiles.add(t);
				}
				
				//Reduce Chance for Environment Tile with each Tile further from the start
				if(queueCounter == 0) {
					queueCounter = enviTiles.size();
					chance -= 10;
				}
			}
		}
		
	}
	
	private void EntryAndExit() {
		
		//Set Random Position
		int randomX = 0;
		int randomY = 0;
		
		
		
		if(roomNum == 1) {
			//Search for a random Room Tile
			while(dungeon[randomX][randomY] != tileColors.get("Room") && dungeon[randomX][randomY] != tileColors.get("MonsterHouse")) {
				randomX = rand.nextInt(dungeon.length);
				randomY = rand.nextInt(dungeon[0].length);
			}
		}
		else {
			//Search for a random Room Tile
			while(dungeon[randomX][randomY] != tileColors.get("Room")) {
				randomX = rand.nextInt(dungeon.length);
				randomY = rand.nextInt(dungeon[0].length);
			}
		}
		
		//Apply Spawn Color to Tile
		dungeon[randomX][randomY] = tileColors.get("Spawn");
		
		
		//Reset Random Position
		randomX = 0;
		randomY = 0;
		
		if(roomNum == 1) {
			//Search for a random Room Tile
			while(dungeon[randomX][randomY] != tileColors.get("Room") && dungeon[randomX][randomY] != tileColors.get("MonsterHouse")) {
				randomX = rand.nextInt(dungeon.length);
				randomY = rand.nextInt(dungeon[0].length);
			}
		}
		else if(!mhStairs) {
			//Search for a random Room Tile
			while(dungeon[randomX][randomY] != tileColors.get("Room")) {
				randomX = rand.nextInt(dungeon.length);
				randomY = rand.nextInt(dungeon[0].length);
			}
		}
		else {
			//Search for a random MHRoom Tile
			while(dungeon[randomX][randomY] != tileColors.get("MonsterHouse")) {
				randomX = rand.nextInt(dungeon.length);
				randomY = rand.nextInt(dungeon[0].length);
			}
		}
		
		
		
		//Apply Stair Color to Tile
		dungeon[randomX][randomY] = tileColors.get("Stairs");
		
	}
	
	private void SetupGraphicRects() {
		gr.clear();
		for(int x = 0; x < dungeon.length; x++) {
			for(int y = 0; y < dungeon[0].length; y++) {
				gr.add(new GraphicsRect(dungeon[x][y], new Tuple(x*tileSize,y*tileSize), new Tuple(tileSize,tileSize)));
			}
		}
		
		for(int x = 0; x <= dungeon.length; x++) {
			gr.add(new GraphicsRect(new Color(50, 50, 50), new Tuple(x*tileSize-1, 0), new Tuple(2,dungeon[0].length*tileSize)));
		}
		for(int y = 0; y <= dungeon[0].length; y++) {
			gr.add(new GraphicsRect(new Color(50, 50, 50), new Tuple(0, y*tileSize-1), new Tuple(dungeon.length*tileSize, 2)));
		}
	}	
	
	private boolean HashSetCompareTuple(HashSet<Tuple> hs, Tuple t) {
		for(Tuple hst : hs) {
			if(hst.x == t.x && hst.y == t.y) return true;
		}
		return false;
	}
}


